const STORAGE_KEY = 'sat_saved_words';

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'SAVE_WORD') {
    chrome.storage.local.get([STORAGE_KEY], (result) => {
      const saved = result[STORAGE_KEY] || {};
      const wordKey = request.data.word.toLowerCase();
      const existing = saved[wordKey];

      saved[wordKey] = {
        word: wordKey,
        meaning_tr: request.data.meaning_tr || 'Manuel Kayıt',
        definition_en: request.data.definition_en || '',
        example: request.data.example || '',
        part_of_speech: request.data.part_of_speech || '',
        status: existing ? existing.status : 'learning',
        saved_at: existing ? existing.saved_at : new Date().toISOString()
      };

      chrome.storage.local.set({ [STORAGE_KEY]: saved }, () => {
        sendResponse({ status: 'success', data: saved[wordKey] });
      });
    });
    return true;
  }

  if (request.action === 'DELETE_WORD') {
    chrome.storage.local.get([STORAGE_KEY], (result) => {
      const saved = result[STORAGE_KEY] || {};
      delete saved[request.data.word.toLowerCase()];
      chrome.storage.local.set({ [STORAGE_KEY]: saved }, () => {
        sendResponse({ status: 'success' });
      });
    });
    return true;
  }
});