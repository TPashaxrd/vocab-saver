let dictionary = {};
let floatingCard = null;

async function loadDictionary() {
  try {
    const url = chrome.runtime.getURL('words.txt');
    const response = await fetch(url);
    const text = await response.text();

    text.split('\n').forEach(line => {
      const match = line.match(/^\s*"([^"]+)"\s*=\s*"([^"]+)"\s*$/);
      if (match) {
        const word = match[1].trim().toLowerCase();
        const parts = match[2].trim().split('|').map(p => p.trim());
        dictionary[word] = {
          meaning_tr: parts[0] || 'Tanım bulunamadı',
          part_of_speech: parts[1] || '',
          definition_en: parts[2] || '',
          example: parts[3] || ''
        };
      }
    });
  } catch (err) {
    console.error('words.txt okunamadı', err);
  }
}

loadDictionary();

document.addEventListener('mouseup', handleSelection);
document.addEventListener('dblclick', handleSelection);

async function translateTextOnline(text) {
  try {
    const res = await fetch(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=tr&dt=t&q=${encodeURIComponent(text)}`);
    const data = await res.json();
    if (data && data[0]) {
      return data[0].map(item => item[0]).join('');
    }
  } catch (err) {
    console.error('Çeviri hatası:', err);
  }
  return null;
}

async function handleSelection(e) {
  if (floatingCard && floatingCard.contains(e.target)) return;

  const selection = window.getSelection();
  if (!selection || selection.isCollapsed) return;

  const rawText = selection.toString().trim();
  if (!rawText) return;

  const wordCount = rawText.split(/\s+/).length;
  const cleanKey = rawText.toLowerCase().replace(/^[^a-zA-Z0-9]+|[^a-zA-Z0-9]+$/g, '');

  if (!cleanKey && wordCount === 1) return;

  const range = selection.getRangeAt(0);
  const rect = range.getBoundingClientRect();

  let data = dictionary[cleanKey] || null;

  if (!data) {
    const onlineMeaning = await translateTextOnline(rawText);
    data = {
      meaning_tr: onlineMeaning || 'Çeviri bulunamadı',
      part_of_speech: wordCount === 1 ? 'Word' : 'Sentence',
      definition_en: '',
      example: ''
    };
  }

  chrome.storage.local.get(['sat_saved_words'], (res) => {
    const savedWords = res.sat_saved_words || {};
    const isSaved = !!savedWords[rawText.toLowerCase()];
    showCard(rawText, cleanKey, data, rect, isSaved, wordCount);
  });
}

function speakWord(text) {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    window.speechSynthesis.speak(utterance);
  }
}

function showCard(originalText, wordKey, data, rect, isSaved, wordCount) {
  removeCard();

  floatingCard = document.createElement('div');
  const top = window.scrollY + rect.bottom + 10;
  let left = window.scrollX + rect.left + (rect.width / 2) - 150;
  left = Math.max(12, Math.min(left, window.innerWidth - 320));

  floatingCard.style.cssText = `
    position: absolute;
    top: ${top}px;
    left: ${left}px;
    z-index: 2147483647;
    width: 310px;
    background: #0f172a;
    border: 1px solid #334155;
    border-radius: 14px;
    padding: 14px;
    box-shadow: 0 20px 35px -5px rgba(0, 0, 0, 0.7);
    color: #f8fafc;
    font-family: system-ui, -apple-system, sans-serif;
    font-size: 13px;
  `;

  const displayTitle = originalText.length > 25 ? originalText.substring(0, 25) + '...' : originalText;
  const typeTag = wordCount === 1 ? (data.part_of_speech || 'kelime') : 'cümle';

  floatingCard.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; border-bottom:1px solid #1e293b; padding-bottom:6px;">
      <div style="display:flex; align-items:center; gap:6px; max-width: 80%;">
        <span style="font-weight:800; font-size:14px; color:#818cf8; text-transform:${wordCount === 1 ? 'uppercase' : 'none'}; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${displayTitle}</span>
        <span style="font-size:9px; background:#1e1b4b; color:#818cf8; padding:1px 5px; border-radius:4px; font-weight:600;">${typeTag}</span>
        <button id="sat-audio-btn" style="background:none; border:none; cursor:pointer; font-size:14px;" title="Sesli Oku">🔊</button>
      </div>
      <button id="sat-close-btn" style="background:none; border:none; color:#64748b; font-size:16px; cursor:pointer;">✕</button>
    </div>

    <div style="margin-bottom:10px; background:rgba(15,23,42,0.8); padding:8px 10px; border-radius:8px;">
      <p style="margin:0; font-weight:600; color:#f1f5f9; word-break:break-word;">🇹🇷 ${data.meaning_tr}</p>
      ${data.definition_en ? `<p style="margin:4px 0 0 0; color:#94a3b8; font-size:10px;">🇬🇧 ${data.definition_en}</p>` : ''}
      ${data.example ? `<p style="margin:6px 0 0 0; color:#cbd5e1; font-size:11px; background:rgba(30,41,59,0.6); padding:6px; border-radius:6px; border-left:2px solid #6366f1;">💬 "${data.example}"</p>` : ''}
    </div>

    <div style="display:flex; gap:6px;">
      <button id="sat-save-btn" style="flex:1; padding:8px; background:${isSaved ? '#059669' : '#4f46e5'}; color:white; border:none; border-radius:6px; font-weight:bold; cursor:pointer;">
        ${isSaved ? '✓ Kaydedildi' : '⭐ Kaydet'}
      </button>
      ${isSaved ? `<button id="sat-delete-btn" style="padding:8px 10px; background:#991b1b; color:#fca5a5; border:none; border-radius:6px; font-weight:bold; cursor:pointer;" title="Sil">🗑️</button>` : ''}
    </div>
  `;

  document.body.appendChild(floatingCard);

  document.getElementById('sat-close-btn').onclick = removeCard;
  document.getElementById('sat-audio-btn').onclick = () => speakWord(originalText);

  document.getElementById('sat-save-btn').onclick = (e) => {
    e.stopPropagation();
    chrome.runtime.sendMessage({
      action: 'SAVE_WORD',
      data: {
        word: originalText,
        meaning_tr: data.meaning_tr,
        example: data.example || '',
        part_of_speech: typeTag
      }
    }, () => {
      removeCard();
      showCard(originalText, wordKey, data, rect, true, wordCount);
    });
  };

  const delBtn = document.getElementById('sat-delete-btn');
  if (delBtn) {
    delBtn.onclick = (e) => {
      e.stopPropagation();
      chrome.runtime.sendMessage({ action: 'DELETE_WORD', data: { word: originalText } }, () => removeCard());
    };
  }
}

function removeCard() {
  if (floatingCard) { floatingCard.remove(); floatingCard = null; }
}

document.addEventListener('mousedown', (e) => {
  if (floatingCard && !floatingCard.contains(e.target)) removeCard();
});