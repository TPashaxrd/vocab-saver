const STORAGE_KEY = 'sat_saved_words';
let savedWords = {};
let reviewQueue = [];
let currentReviewIndex = 0;
let isFlipped = false;
let editingWordKey = null;

document.addEventListener('DOMContentLoaded', async () => {
  setupTabs();
  await loadWords();

  document.getElementById('search-input').addEventListener('input', renderWordList);
  document.getElementById('status-filter').addEventListener('change', renderWordList);
  document.getElementById('export-btn').addEventListener('click', exportWords);

  document.getElementById('flashcard').addEventListener('click', flipCard);
  document.getElementById('btn-grade-again').addEventListener('click', () => gradeWord('learning'));
  document.getElementById('btn-grade-master').addEventListener('click', () => gradeWord('mastered'));
});

function setupTabs() {
  const tabs = document.querySelectorAll('.nav-btn');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.view-panel').forEach(v => v.classList.remove('active'));

      tab.classList.add('active');
      const targetView = document.getElementById(tab.dataset.tab);
      if (targetView) targetView.classList.add('active');

      if (tab.dataset.tab === 'review-tab') startReview();
    });
  });
}

async function loadWords() {
  const res = await chrome.storage.local.get([STORAGE_KEY]);
  savedWords = res[STORAGE_KEY] || {};
  updateStats();
  renderWordList();
}

function updateStats() {
  const list = Object.values(savedWords);
  document.getElementById('stat-total').innerText = list.length;
  document.getElementById('stat-learning').innerText = list.filter(w => w.status === 'learning').length;
  document.getElementById('stat-mastered').innerText = list.filter(w => w.status === 'mastered').length;
}

function renderWordList() {
  const container = document.getElementById('word-list');
  const search = document.getElementById('search-input').value.toLowerCase();
  const filter = document.getElementById('status-filter').value;

  container.innerHTML = '';

  const list = Object.values(savedWords).filter(w => {
    const matchesSearch = w.word.toLowerCase().includes(search) || (w.meaning_tr && w.meaning_tr.toLowerCase().includes(search));
    const matchesFilter = filter === 'all' || w.status === filter;
    return matchesSearch && matchesFilter;
  });

  if (list.length === 0) {
    container.innerHTML = `<div style="text-align:center; padding:20px; color:#64748b; font-size:11px;">Kelime bulunamadı.</div>`;
    return;
  }

  list.sort((a, b) => new Date(b.saved_at) - new Date(a.saved_at));

  list.forEach(item => {
    const card = document.createElement('div');
    card.className = 'word-card';

    const isEditing = editingWordKey === item.word;

    if (isEditing) {
      // DÜZENLEME FORMU
      card.innerHTML = `
        <div class="word-header-row">
          <span class="word-term">${item.word} (Düzenleniyor)</span>
        </div>
        <div class="edit-form">
          <input type="text" class="edit-input" id="edit-meaning-${item.word}" value="${item.meaning_tr || ''}" placeholder="Türkçe Anlamı">
          <input type="text" class="edit-input" id="edit-example-${item.word}" value="${item.example || ''}" placeholder="Örnek Cümle">
          <div class="edit-actions">
            <button class="btn-sm btn-cancel" id="cancel-edit-btn">İptal</button>
            <button class="btn-sm btn-save" id="save-edit-btn">Kaydet</button>
          </div>
        </div>
      `;

      card.querySelector('#cancel-edit-btn').onclick = () => {
        editingWordKey = null;
        renderWordList();
      };

      card.querySelector('#save-edit-btn').onclick = async () => {
        const newMeaning = card.querySelector(`#edit-meaning-${item.word}`).value.trim();
        const newExample = card.querySelector(`#edit-example-${item.word}`).value.trim();

        savedWords[item.word].meaning_tr = newMeaning || 'Manuel Kayıt';
        savedWords[item.word].example = newExample;

        await chrome.storage.local.set({ [STORAGE_KEY]: savedWords });
        editingWordKey = null;
        renderWordList();
      };

    } else {
      // NORMAL KART GÖRÜNÜMÜ
      card.innerHTML = `
        <div class="word-header-row">
          <span class="word-term">${item.word}</span>
          <div>
            <button class="icon-btn audio-btn" title="Sesli Oku">🔊</button>
            <button class="icon-btn edit-btn" title="Düzenle">✏️</button>
            <button class="icon-btn danger delete-btn" title="Sil">🗑️</button>
          </div>
        </div>
        <div class="word-meaning-text">🇹🇷 ${item.meaning_tr}</div>
        ${item.example ? `<div class="word-ex-text">💬 "${item.example}"</div>` : ''}
      `;

      // Sesli Okuma
      card.querySelector('.audio-btn').onclick = () => {
        if ('speechSynthesis' in window) {
          window.speechSynthesis.cancel();
          const u = new SpeechSynthesisUtterance(item.word);
          u.lang = 'en-US';
          window.speechSynthesis.speak(u);
        }
      };

      // Düzenleme Butonu Olayı
      card.querySelector('.edit-btn').onclick = () => {
        editingWordKey = item.word;
        renderWordList();
      };

      // Silme Butonu Olayı
      card.querySelector('.delete-btn').onclick = async () => {
        if (confirm(`"${item.word.toUpperCase()}" kelimesini silmek istiyor musunuz?`)) {
          delete savedWords[item.word];
          await chrome.storage.local.set({ [STORAGE_KEY]: savedWords });
          updateStats();
          renderWordList();
        }
      };
    }

    container.appendChild(card);
  });
}

// Flashcard Çalışma Modu
function startReview() {
  reviewQueue = Object.values(savedWords);
  currentReviewIndex = 0;
  showNextCard();
}

function showNextCard() {
  isFlipped = false;
  document.getElementById('fc-answer').style.display = 'none';
  document.getElementById('grade-btns').style.display = 'none';
  document.getElementById('fc-hint').style.display = 'block';

  if (reviewQueue.length === 0) {
    document.getElementById('fc-word').innerText = 'TEBRİKLER!';
    document.getElementById('fc-hint').innerText = 'Çalışılacak kelime yok.';
    return;
  }

  if (currentReviewIndex >= reviewQueue.length) currentReviewIndex = 0;

  const item = reviewQueue[currentReviewIndex];
  document.getElementById('fc-word').innerText = item.word;
  document.getElementById('fc-meaning').innerText = '🇹🇷 ' + item.meaning_tr;
  document.getElementById('fc-ex').innerText = item.example ? `💬 "${item.example}"` : '';
}

function flipCard() {
  if (reviewQueue.length === 0) return;
  isFlipped = !isFlipped;
  document.getElementById('fc-answer').style.display = isFlipped ? 'block' : 'none';
  document.getElementById('grade-btns').style.display = isFlipped ? 'grid' : 'none';
  document.getElementById('fc-hint').style.display = isFlipped ? 'none' : 'block';
}

async function gradeWord(newStatus) {
  const item = reviewQueue[currentReviewIndex];
  if (!item) return;

  savedWords[item.word].status = newStatus;
  await chrome.storage.local.set({ [STORAGE_KEY]: savedWords });

  updateStats();
  currentReviewIndex++;
  showNextCard();
}

function exportWords() {
  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(savedWords, null, 2));
  const dl = document.createElement('a');
  dl.setAttribute("href", dataStr);
  dl.setAttribute("download", `sat_words_${new Date().toISOString().slice(0,10)}.json`);
  document.body.appendChild(dl);
  dl.click();
  dl.remove();
}